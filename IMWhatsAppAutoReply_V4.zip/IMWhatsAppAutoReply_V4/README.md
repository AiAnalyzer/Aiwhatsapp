# IM Auto Reply V4

V4 is a clean-install Android build with a fresh application ID:
`com.imintelligence.imautoreply.v4`

It keeps the approved green IM Auto Reply branding and the three-message first-contact auto-reply workflow.

The GitHub workflow builds a signed debug APK and refuses to upload it unless ZIP integrity, APK signature, package ID, and application label verification all pass.
