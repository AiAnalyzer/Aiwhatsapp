# IM Auto Reply V9

V9 keeps the permanent package ID `com.imintelligence.imautoreply` and increments only the version to 9.0 (versionCode 9).

V9 uses a conventional Android Gradle build (AGP 8.5.2 / Gradle 8.7 / Java 17), no custom release re-signing, and the GitHub workflow performs an emulator installation and launch test before publishing the APK artifact.

Functions:
- WhatsApp Business notification listener
- First-contact-only 3-message auto-reply sequence
- Editable Reply 1 / Reply 2 / Reply 3
- Editable delays
- Master ON/OFF
- Skip group conversations
- Local reply history and reset/export behavior from prior versions

Package: `com.imintelligence.imautoreply`
Version: 9.0 (9)
