package com.imintelligence.imautoreply;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.LinkedHashSet;
import java.util.Set;

public final class AppPrefs {
    private static final String PREF = "im_auto_reply";
    private static final String KEY_HISTORY = "history_keys";
    private static final String KEY_HISTORY_LINES = "history_lines";

    private AppPrefs() {}

    public static SharedPreferences p(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    public static boolean enabled(Context c) { return p(c).getBoolean("enabled", false); }
    public static String r1(Context c) { return p(c).getString("r1", "Thank you for contacting IM Analyzer Management! 👋\nWe are happy to assist you."); }
    public static String r2(Context c) { return p(c).getString("r2", "We provide Pan-India Beauty Salon, Cosmetics & Personal Care Product B2B Database."); }
    public static String r3(Context c) { return p(c).getString("r3", "Please reply here for price, sample data, or any questions. We are ready to help!"); }
    public static int d2(Context c) { return p(c).getInt("d2", 3); }
    public static int d3(Context c) { return p(c).getInt("d3", 3); }
    public static boolean skipGroups(Context c) { return p(c).getBoolean("skip_groups", true); }

    public static synchronized boolean hasCustomer(Context c, String key) {
        return p(c).getStringSet(KEY_HISTORY, new LinkedHashSet<>()).contains(key);
    }

    public static synchronized void addCustomer(Context c, String key, String displayLine) {
        Set<String> old = p(c).getStringSet(KEY_HISTORY, new LinkedHashSet<>());
        LinkedHashSet<String> copy = new LinkedHashSet<>(old);
        copy.add(key);
        String lines = p(c).getString(KEY_HISTORY_LINES, "");
        if (!lines.isEmpty()) lines = displayLine + "\n" + lines;
        else lines = displayLine;
        p(c).edit().putStringSet(KEY_HISTORY, copy).putString(KEY_HISTORY_LINES, lines).apply();
    }

    public static int historyCount(Context c) {
        return p(c).getStringSet(KEY_HISTORY, new LinkedHashSet<>()).size();
    }

    public static String historyLines(Context c) {
        return p(c).getString(KEY_HISTORY_LINES, "");
    }

    public static void resetHistory(Context c) {
        p(c).edit().remove(KEY_HISTORY).remove(KEY_HISTORY_LINES).apply();
    }
}
