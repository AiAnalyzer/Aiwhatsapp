# IM Auto Reply V8

Android auto-reply helper for WhatsApp Business notifications.

## V8 identity
- App name: IM Auto Reply
- Permanent application ID: `com.imintelligence.imautoreply`
- Version code: 8
- Version name: 8.0
- Min SDK: 23
- Target/Compile SDK: 35

## V8 behavior
- Notification Access connection button
- Auto Reply ON/OFF
- Three editable reply messages
- Editable Reply 2 / Reply 3 delays
- First-contact-only local history
- Optional group-chat ignore
- History reset/export
- WhatsApp Business package only (`com.whatsapp.w4b`)

## Build
Use the supplied GitHub workflow at `.github/workflows/build-apk.yml`.
The artifact contains two independently packaged APKs:
1. `IM-Auto-Reply-V8.apk` — explicitly aligned and signed release APK.
2. `IM-Auto-Reply-V8-DEBUG.apk` — Android Gradle Plugin standard debug APK.

The workflow also outputs badging/signature/zipalign reports for diagnosis.
