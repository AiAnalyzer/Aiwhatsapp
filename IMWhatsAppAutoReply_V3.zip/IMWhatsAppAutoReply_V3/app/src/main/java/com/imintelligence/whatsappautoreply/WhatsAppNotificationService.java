package com.imintelligence.whatsappautoreply;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.text.TextUtils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

public class WhatsAppNotificationService extends NotificationListenerService {
    private static final String WA_BUSINESS = "com.whatsapp.w4b";
    private Handler worker;
    private final Set<String> inProgress = new HashSet<>();

    @Override public void onCreate() {
        super.onCreate();
        HandlerThread ht = new HandlerThread("IMAutoReplyWorker");
        ht.start();
        worker = new Handler(ht.getLooper());
    }

    @Override public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null || !WA_BUSINESS.equals(sbn.getPackageName()) || !AppPrefs.enabled(this)) return;
        Notification n = sbn.getNotification();
        if (n == null || n.extras == null) return;

        Bundle ex = n.extras;
        if (AppPrefs.skipGroups(this) && ex.getBoolean(Notification.EXTRA_IS_GROUP_CONVERSATION, false)) return;

        String title = text(ex.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE));
        if (title.isEmpty()) title = text(ex.getCharSequence(Notification.EXTRA_TITLE));
        if (title.isEmpty() || isLikelySummary(title, ex)) return;

        Notification.Action action = findReplyAction(n);
        if (action == null) return;

        String shortcut = n.getShortcutId();
        String customerKey = !TextUtils.isEmpty(shortcut)
                ? "shortcut:" + shortcut
                : "title:" + title.toLowerCase(Locale.ROOT).trim();

        synchronized (inProgress) {
            if (inProgress.contains(customerKey) || AppPrefs.hasCustomer(this, customerKey)) return;
            inProgress.add(customerKey);
        }

        final String displayTitle = title;
        worker.post(() -> runSequence(action, customerKey, displayTitle));
    }

    private void runSequence(Notification.Action firstAction, String key, String title) {
        int sent = 0;
        try {
            String r1 = AppPrefs.r1(this).trim();
            String r2 = AppPrefs.r2(this).trim();
            String r3 = AppPrefs.r3(this).trim();

            Notification.Action action = firstAction;
            if (!r1.isEmpty()) {
                send(action, r1);
                sent++;
            }
            if (!r2.isEmpty()) {
                sleep(AppPrefs.d2(this));
                action = freshReplyAction(key, title, action);
                send(action, r2);
                sent++;
            }
            if (!r3.isEmpty()) {
                sleep(AppPrefs.d3(this));
                action = freshReplyAction(key, title, action);
                send(action, r3);
                sent++;
            }

            if (sent > 0) {
                String dt = new SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.US).format(new Date());
                AppPrefs.addCustomer(this, key, title + "\t" + dt);
            }
        } catch (Exception ignored) {
            // If WhatsApp cancels/replaces its notification reply PendingIntent,
            // do not mark the customer completed so a later incoming message can retry.
        } finally {
            synchronized (inProgress) { inProgress.remove(key); }
        }
    }

    private Notification.Action freshReplyAction(String key, String title, Notification.Action fallback) {
        try {
            StatusBarNotification[] active = getActiveNotifications();
            if (active == null) return fallback;
            for (StatusBarNotification sbn : active) {
                if (sbn == null || !WA_BUSINESS.equals(sbn.getPackageName())) continue;
                Notification n = sbn.getNotification();
                if (n == null || n.extras == null) continue;
                String shortcut = n.getShortcutId();
                String t = text(n.extras.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE));
                if (t.isEmpty()) t = text(n.extras.getCharSequence(Notification.EXTRA_TITLE));
                String candidate = !TextUtils.isEmpty(shortcut)
                        ? "shortcut:" + shortcut
                        : "title:" + t.toLowerCase(Locale.ROOT).trim();
                if (key.equals(candidate) || title.equalsIgnoreCase(t)) {
                    Notification.Action a = findReplyAction(n);
                    if (a != null) return a;
                }
            }
        } catch (Exception ignored) { }
        return fallback;
    }

    private void sleep(int seconds) {
        try {
            Thread.sleep(Math.max(0, seconds) * 1000L);
        } catch (InterruptedException ignored) {
            Thread.currentThread().interrupt();
        }
    }

    private void send(Notification.Action action, String message) throws PendingIntent.CanceledException {
        if (action == null || action.actionIntent == null) throw new IllegalStateException("No reply action");
        RemoteInput[] inputs = action.getRemoteInputs();
        if (inputs == null || inputs.length == 0) throw new IllegalStateException("No RemoteInput");
        Bundle results = new Bundle();
        for (RemoteInput input : inputs) results.putCharSequence(input.getResultKey(), message);
        Intent fill = new Intent();
        RemoteInput.addResultsToIntent(inputs, fill, results);
        action.actionIntent.send(this, 0, fill);
    }

    private Notification.Action findReplyAction(Notification n) {
        if (n.actions == null) return null;
        for (Notification.Action a : n.actions) {
            if (a == null || a.actionIntent == null) continue;
            RemoteInput[] ri = a.getRemoteInputs();
            if (ri != null && ri.length > 0) return a;
        }
        return null;
    }

    private String text(CharSequence s) {
        return s == null ? "" : s.toString().trim();
    }

    private boolean isLikelySummary(String title, Bundle ex) {
        CharSequence info = ex.getCharSequence(Notification.EXTRA_INFO_TEXT);
        String t = title.toLowerCase(Locale.ROOT);
        return t.equals("whatsapp business")
                || t.matches("\\d+ new messages?")
                || (info != null && t.contains("new messages"));
    }
}
