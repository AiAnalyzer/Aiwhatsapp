# IM WhatsApp Auto Reply V3

Small Android app for WhatsApp Business notification auto-replies.

## V3 behavior
- Master Auto Reply ON/OFF
- Reply 1 immediately
- Reply 2 after configurable delay
- Reply 3 after configurable delay
- Remembers customers so the sequence is sent only once until history is reset
- Ignores WhatsApp group conversations when enabled
- Reply history + CSV export
- Uses Android Notification Access / notification RemoteInput; no WhatsApp password or Meta API key

## Build
This project can be opened directly in Android Studio. The supplied GitHub workflow can build either:
1. an extracted project at the repository root, or
2. this ZIP uploaded into a repository.

For safest testing, use a second WhatsApp number before enabling it for customer traffic.
