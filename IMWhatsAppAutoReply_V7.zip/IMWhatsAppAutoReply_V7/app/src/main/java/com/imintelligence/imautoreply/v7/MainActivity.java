package com.imintelligence.imautoreply.v7;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.widget.*;
import android.graphics.Color;

public class MainActivity extends Activity {
    private Switch sw;
    private EditText r1, r2, r3, d2, d3;
    private CheckBox skipGroups;
    private TextView access;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        sw = findViewById(R.id.switchEnabled);
        r1 = findViewById(R.id.editReply1); r2 = findViewById(R.id.editReply2); r3 = findViewById(R.id.editReply3);
        d2 = findViewById(R.id.editDelay2); d3 = findViewById(R.id.editDelay3);
        skipGroups = findViewById(R.id.checkSkipGroups); access = findViewById(R.id.txtAccess);

        load();
        findViewById(R.id.btnAccess).setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)));
        findViewById(R.id.btnSave).setOnClickListener(v -> save());
        findViewById(R.id.btnHistory).setOnClickListener(v -> startActivity(new Intent(this, HistoryActivity.class)));
    }

    @Override protected void onResume() { super.onResume(); refreshAccess(); }

    private void load() {
        sw.setChecked(AppPrefs.enabled(this));
        r1.setText(AppPrefs.r1(this)); r2.setText(AppPrefs.r2(this)); r3.setText(AppPrefs.r3(this));
        d2.setText(String.valueOf(AppPrefs.d2(this))); d3.setText(String.valueOf(AppPrefs.d3(this)));
        skipGroups.setChecked(AppPrefs.skipGroups(this));
    }

    private int intVal(EditText e, int def) {
        try { return Math.max(0, Math.min(300, Integer.parseInt(e.getText().toString().trim()))); }
        catch (Exception x) { return def; }
    }

    private void save() {
        if (TextUtils.isEmpty(r1.getText().toString().trim())) {
            Toast.makeText(this, "Reply 1 cannot be empty", Toast.LENGTH_SHORT).show(); return;
        }
        AppPrefs.p(this).edit()
            .putBoolean("enabled", sw.isChecked())
            .putString("r1", r1.getText().toString().trim())
            .putString("r2", r2.getText().toString().trim())
            .putString("r3", r3.getText().toString().trim())
            .putInt("d2", intVal(d2,3)).putInt("d3", intVal(d3,3))
            .putBoolean("skip_groups", skipGroups.isChecked()).apply();
        Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show();
    }

    private boolean notificationAccessEnabled() {
        String flat = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
        if (flat == null || flat.isEmpty()) return false;
        String pkg = getPackageName();
        for (String s : flat.split(":")) {
            ComponentName cn = ComponentName.unflattenFromString(s);
            if (cn != null && pkg.equals(cn.getPackageName())) return true;
        }
        return false;
    }

    private void refreshAccess() {
        boolean ok = notificationAccessEnabled();
        access.setText(ok ? "Notification Access: Connected ✓" : "Notification Access: Not connected");
        access.setTextColor(ok ? Color.rgb(0,145,80) : Color.rgb(160,60,45));
    }
}
