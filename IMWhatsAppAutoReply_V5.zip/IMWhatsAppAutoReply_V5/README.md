# IM Auto Reply V5

Android notification-based auto reply helper for WhatsApp Business.

## V5 build fixes
- Fresh package/application ID: `com.imintelligence.imautoreply.v5`
- All Java package declarations and source folders aligned with the namespace.
- Removed the stale V4/V1 fully-qualified `R` reference that caused `compileDebugJavaWithJavac` to fail.
- Android SDK 35 / Java 17 / AGP 8.7.3.
- Notification listener service declared with the required binding permission.
- V5 workflow rejects stale package references before compilation.
- Workflow verifies APK ZIP integrity, APK signature, package ID, app label and SDK metadata before uploading the artifact.

## Important
This app relies on Android notification `RemoteInput` exposed by WhatsApp Business. It is not the official Meta WhatsApp Business Platform API, so WhatsApp/Android changes can affect reply behavior.
