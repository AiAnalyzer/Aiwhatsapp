package com.imintelligence.imautoreply.v6;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class HistoryActivity extends Activity {
    private TextView count, history;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b); setContentView(R.layout.activity_history);
        count = findViewById(R.id.txtCount); history = findViewById(R.id.txtHistory);
        findViewById(R.id.btnReset).setOnClickListener(v -> new AlertDialog.Builder(this)
            .setTitle("Reset history?")
            .setMessage("All saved customers will become eligible for the 3-message welcome sequence again.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Reset", (d,w) -> { AppPrefs.resetHistory(this); refresh(); })
            .show());
        findViewById(R.id.btnExport).setOnClickListener(v -> exportCsv());
        refresh();
    }

    @Override protected void onResume(){ super.onResume(); refresh(); }

    private void refresh() {
        int n = AppPrefs.historyCount(this);
        count.setText(n + (n == 1 ? " customer" : " customers"));
        String s = AppPrefs.historyLines(this);
        history.setText(s.isEmpty() ? "No customer has received the auto-reply sequence yet." : s.replace("\t", "   •   "));
    }

    private void exportCsv() {
        String lines = AppPrefs.historyLines(this);
        if (lines.isEmpty()) { Toast.makeText(this,"Nothing to export",Toast.LENGTH_SHORT).show(); return; }
        StringBuilder csv = new StringBuilder("Customer,Date/Time,Status\n");
        for (String line : lines.split("\\n")) {
            String[] p = line.split("\\t", -1);
            String customer = p.length>0?p[0]:"";
            String dt = p.length>1?p[1]:"";
            csv.append('"').append(customer.replace("\"","\"\"")).append("\",\"")
               .append(dt.replace("\"","\"\"")).append("\",\"3 replies sent\"\n");
        }
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/csv");
        send.putExtra(Intent.EXTRA_SUBJECT, "IM Auto Reply History " + new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date()));
        send.putExtra(Intent.EXTRA_TEXT, csv.toString());
        startActivity(Intent.createChooser(send, "Export history"));
    }
}
