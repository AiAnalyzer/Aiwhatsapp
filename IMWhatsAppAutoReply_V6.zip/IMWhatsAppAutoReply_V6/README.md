# IM Auto Reply V6

Android app for a simple first-contact WhatsApp Business auto-reply sequence using Android notification reply actions.

## Identity
- App name: IM Auto Reply
- Package/Application ID: `com.imintelligence.imautoreply.v6`
- Version: 6.0
- Min SDK: 23
- Target/Compile SDK: 35

## Features
- Master Auto Reply ON/OFF
- Reply 1 immediately
- Reply 2 and Reply 3 with editable delays
- First-contact history protection
- Ignore group conversations option
- Notification Access status/button
- Reply history, reset history, CSV share/export
- WhatsApp Business package only (`com.whatsapp.w4b`)

## Important
This app uses Android NotificationListenerService + RemoteInput. It does not use the official Meta WhatsApp Business API. WhatsApp/Android notification behavior can change, so test with a second phone before relying on it for customer traffic.
